# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0002_auto_20170207_1755'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='sum',
            options={'verbose_name': '\u52a0\u6cd5', 'verbose_name_plural': '\u52a0\u6cd5'},
        ),
    ]
