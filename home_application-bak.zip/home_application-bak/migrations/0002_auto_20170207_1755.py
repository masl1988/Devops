# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0001_initial'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='sum',
            options={'verbose_name': '\u6570\u503c1', 'verbose_name_plural': '\u6570\u503c1'},
        ),
    ]
